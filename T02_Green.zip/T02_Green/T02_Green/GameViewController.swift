//
//  GameViewController.swift
//  T02_Green
//
//  Created by Bryan Okegbe on 11/9/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//

import UIKit
import AudioToolbox

class GameViewController: UIViewController, CountdownTimerDelegate{
 
    @IBOutlet weak var startOutlet: UIButton!
    //list of tasks to complete
    var taskArray = ["Bed Making", "Vaccuming", "Toilet Cleaning", "Dusting", "Window Wiping", "Arranging Items in Room"]
    //global variables for tracking
    @IBOutlet weak var hours: UILabel!
    @IBOutlet weak var minutes: UILabel!
    @IBOutlet weak var seconds: UILabel!
    @IBOutlet weak var counterView: UIStackView!
    @IBOutlet weak var afterMessage: UILabel!
    @IBOutlet weak var progressBar: ProgressBar!
    
    var userDatabase : [User] = []
    var curUser: String = "test2"
    var currentUser : User?
    var userPoints : Int32 = 0
    
    
    
    
    
    //MARK - Vars
    
    var countdownTimerDidStart = false
    
    lazy var countdownTimer: CountdownTimer = {
        let countdownTimer = CountdownTimer()
        return countdownTimer
    }()
    
    
    // Seconds for timer
    let selectedSecs:Int = 180
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        countdownTimer.delegate = self
        countdownTimer.setTimer(hours: 0, minutes: 0, seconds: selectedSecs)
        progressBar.setProgressBar(hours: 0, minutes: 0, seconds: selectedSecs)
//        finishBtn.isEnabled = false
//        finishBtn.alpha = 0.5
        
        view.addSubview(afterMessage)
        
        var constraintCenter = NSLayoutConstraint(item: afterMessage, attribute: .centerX, relatedBy: .equal, toItem: self.view, attribute: .centerX, multiplier: 1, constant: 0)
        self.view.addConstraint(constraintCenter)
        constraintCenter = NSLayoutConstraint(item: afterMessage, attribute: .centerY, relatedBy: .equal, toItem: self.view, attribute: .centerY, multiplier: 1, constant: 0)
        self.view.addConstraint(constraintCenter)
        
        afterMessage.isHidden = true
        counterView.isHidden = false
        self.navigationItem.hidesBackButton = true
        
        //Starting the Timer
        afterMessage.isHidden = true
        counterView.isHidden = false
        
        startOutlet.isHidden = true
        
        reloadData()
        getUser()
        
//        countdownTimer.start()
//        progressBar.start()
//        countdownTimerDidStart = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        start(startOutlet)
    }
    
    //getting current user
    func getUser(){
        for users in userDatabase {
            if users.username == curUser{
                currentUser = users
                userPoints = (currentUser?.points)!
                return
            }
        }
    }
    //when all tasks are completed, check if completed on time and award points
    override func viewWillDisappear(_ animated: Bool) {
        if (!counterView.isHidden){
            userPoints += 10
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                print("Cannot fetch app delegate")
                return
            }
            let managedContext = appDelegate.persistentContainer.viewContext
            userDatabase[userDatabase.index(of: currentUser!)!].points = userPoints
            
            do {
                try managedContext.save()
            }
            catch let error as NSError {
                print("There was an error with saving: \(error)")
            }
        }
    }
    
    //retrieving database
    func reloadData() {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            print("Cannot fetch app delegate")
            return
        }
        //getting the actual storage object
        let managedContext = appDelegate.persistentContainer.viewContext
        
        do {
            //loading in to local variable
            userDatabase = try managedContext.fetch(User.fetchRequest())
        }
        catch let error as NSError {
            print("Cannot load data: \(error)")
        }
    }
    
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    
    
    //MARK: - Countdown Timer Delegate
    
    func countdownTime(time: (hours: String, minutes: String, seconds: String)) {
        hours.text = time.hours
        minutes.text = time.minutes
        seconds.text = time.seconds
    }
    
    
    
    //when timer finishes
    func countdownTimerDone() {
        
        counterView.isHidden = true
        afterMessage.isHidden = false
        afterMessage.textColor = UIColor(red:0.72, green:0.20, blue:0.08, alpha:1.0)
        UIView.transition(with: afterMessage, duration: 0.7, options: .transitionFlipFromBottom, animations: nil, completion: nil)
        
        
        seconds.text = String(selectedSecs)
        countdownTimerDidStart = false
        
        AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
        
        print("countdownTimerDone")
    }
    
    
    //MARK: - Actions
    
    /*@IBAction func startTimer(_ sender: UIButton) {
        
        afterMessage.isHidden = true
        counterView.isHidden = false
        
        finishBtn.isEnabled = true
        finishBtn.alpha = 1.0
        
        if !countdownTimerDidStart{
            countdownTimer.start()
            progressBar.start()
            countdownTimerDidStart = true
            startBtn.setTitle("PAUSE",for: .normal)
            startBtn.titleLabel?.adjustsFontSizeToFitWidth = true
            
        }else{
            countdownTimer.pause()
            progressBar.pause()
            countdownTimerDidStart = false
            startBtn.setTitle("RESUME",for: .normal)
            startBtn.titleLabel?.adjustsFontSizeToFitWidth = true
        }

    }
  
   */
    
    
    //starting the timer
    @IBAction func start(_ sender: UIButton) {
        if !countdownTimerDidStart{
            countdownTimer.start()
            progressBar.start()
            countdownTimerDidStart = true
//            startBtn.setTitle("PAUSE",for: .normal)
//            startBtn.titleLabel?.adjustsFontSizeToFitWidth = true
            
        }
        startOutlet.isEnabled = false
    }
    
    //for if we want to stop the timer. this is unused for now
    @IBAction func stopTimer(_ sender: UIButton) {
        counterView.isHidden = false
        countdownTimer.stop()
        progressBar.stop()
        countdownTimerDidStart = false
//        finishBtn.isEnabled = false
//        finishBtn.alpha = 0.5
//        startBtn.setTitle("START",for: .normal)
        afterMessage.isHidden = true
      
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return taskArray.count // your number of cell here
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "taskCell", for: indexPath)
        // your cell coding
        cell.textLabel?.text = taskArray[indexPath.row]
        return cell
        
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        // cell selected code here
    }
    
    
    
    
}

