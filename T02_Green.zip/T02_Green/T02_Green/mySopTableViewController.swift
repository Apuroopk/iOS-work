//
//  mySopTableViewController.swift
//  T02_Green
//
//  Created by Amanda Lowe on 11/22/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//

import UIKit

class mySopTableViewController: UITableViewController {
    
    var curUser : String?

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "SOP"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return sectionHeaders.count
    }

    //populating cells with sop general info
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "sopCell", for: indexPath)
        
        cell.textLabel?.textColor = UIColor.black

        // Configure the cell...
        cell.textLabel?.text = String(describing: sectionHeaders[indexPath.row])

        return cell
    }
    
    
    //function to send data to next view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toHamburger" {
            //passing username to next controller
            if let destination = segue.destination as? HamburgerController{
                destination.curUser = curUser
            }
        } else{
            //passing album chosen to next controller
            if let indexPath = tableView.indexPathForSelectedRow,
                let destination = segue.destination as? sopDisplay{
                //actual destination view controller since it is embedded
                destination.index = indexPath.row
                destination.sopTitle = sectionHeaders[indexPath.row]
            }
        }
        
    }
    

    //info to populate cells with. general sections
    var sectionHeaders = ["Guest Room", "Fire Prevention", "First Aid", "Security", "Food Safety", "Workplace Safety", "Inspections and Support", "Accident Reporting", "Control of Hazardous Substances", "Supervision of Health Club", "Emergency Procedures and Incident Control", "Emergency Power", "Engineering Safety Inspections", "Water Hygiene", "Human Resources and Team Members" ]
    
}

