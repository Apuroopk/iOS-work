//
//  User+CoreDataClass.swift
//  T02_Green
//
//  Created by Garie on 11/25/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
