//
//  myRSTableViewController.swift
//  T02_Green
//
//  Created by Sai Apuroop Kapavarapu on 11/27/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//

import UIKit

class myTableViewCell: UITableViewCell {
        
    @IBOutlet weak var hotelImage: UIImageView!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var roomNoLabel: UILabel!
    @IBOutlet weak var roomTypeLabel: UILabel!
        
    }
    
class myRSTableViewController: UITableViewController {
    
        var curUser : String?
    
    //all the rooms to be listed. These will reset when app quits for demo purposes
        var roomNO : [String] = ["501","502","503","504","201","301","401","202","302","402","203","303","403","204","304","404","205","305","405"]
        var roomType : [String] = ["Premium","Suite Pool","Suite","Beach View","Luxury","Twin","Executive Suite","Family","City View","Executive Suite","Standard","Standard Suite","Premium","Single","Family","Executive Family","Single","Suite","Family"]
        var roomStatus : [String] = ["Occupied","On Change","Vacant","Needs Service","Complete","Occupied","On Change","Vacant","Needs Service","Complete","Occupied","On Change","Vacant","Needs Service","Complete","Occupied","Needs Service","Vacant","Complete"]
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
        override func viewDidLoad() {
            super.viewDidLoad()
            navigationItem.title = "Room Status"
            
            self.tableView.estimatedRowHeight = 100
            self.tableView.rowHeight = 100
            
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            
        }
        
        
        override func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
        
        override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return roomNO.count
        }
        
        
        override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! myTableViewCell
            
            cell.statusLabel?.text = roomType[indexPath.row]
            cell.roomNoLabel?.text = "#" + roomNO[indexPath.row]
            cell.roomTypeLabel?.text = roomStatus[indexPath.row]
            cell.hotelImage?.image = UIImage(named:self.roomNO[indexPath.row])
            
            // cell.backgroundColor = UIColor(red:0.21, green:0.79, blue:0.73, alpha:1.0)
            
            if (roomStatus[indexPath.row] == "Needs Service") {
                cell.roomTypeLabel?.textColor = UIColor(red:0.26, green:0.63, blue:0.11, alpha:1.0)
            }
            
            if (roomStatus[indexPath.row] == "On Change") {
                cell.roomTypeLabel?.textColor = UIColor(red:0.88, green:0.81, blue:0.04, alpha:1.0)
            }
            
            if (roomStatus[indexPath.row] == "Occupied" || roomStatus[indexPath.row] == "Vacant" || roomStatus[indexPath.row] == "Complete") {
                cell.roomTypeLabel?.textColor = UIColor(red:0.78, green:0.09, blue:0.09, alpha:1.0)
            }
            
            

            return cell
        }
    
    //figuring out if room needs service when selected
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (roomStatus[indexPath.row] == "Needs Service") {
            self.performSegue(withIdentifier: "todo", sender: self)
            roomStatus[indexPath.row] = "Complete"
            self.tableView.reloadData()
        }
        if (roomStatus[indexPath.row] == "Occupied" || roomStatus[indexPath.row] == "Vacant" || roomStatus[indexPath.row] == "Complete") {
            alertControllerDisplay()
            self.tableView.cellForRow(at: indexPath)?.textLabel?.textColor = UIColor.red
        }
        if (roomStatus[indexPath.row] == "On Change") {
            alertControllerdisplay2()
            self.tableView.cellForRow(at: indexPath)?.textLabel?.textColor = UIColor.yellow
        }
    }
    //if rooms dont need work
    func alertControllerDisplay () {
        let alertControllerOccupied = UIAlertController(title: "Room cleaned!",message: "Please come back later", preferredStyle: .alert)
        let okButton = UIAlertAction(title: "OK",style: .default) { (result : UIAlertAction) in print("ok") }
        alertControllerOccupied.addAction(okButton)
        self.present(alertControllerOccupied,animated: true,completion: nil)
    }
    //if rooms dont need work
    func alertControllerdisplay2 () {
        let alertControllerOnChange = UIAlertController(title: "Work in Progress!",message: "Please select other room", preferredStyle: .alert)
        let ok1Button = UIAlertAction(title: "OK",style: .default) { (result : UIAlertAction) in print("ok") }
        alertControllerOnChange.addAction(ok1Button)
        self.present(alertControllerOnChange,animated: true,completion: nil)
    }
    
    //function to send data to next view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "todo" {
            //passing username to next controller
            if let destination = segue.destination as? GameViewController{
                destination.curUser = curUser!
            }
        }
        else if segue.identifier == "toHamburger" {
            //passing username to next controller
            if let destination = segue.destination as? HamburgerController{
                destination.curUser = curUser
            }
        }
        
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


}
