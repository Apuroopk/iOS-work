//
//  sopInfo.swift
//  T02_Green
//
//  Created by Amanda Lowe on 11/22/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//

import Foundation


class sopInfo {
    
    //unused. for reference when filling out sop tables
    var sectionHeaders = ["Guest Room", "Fire Prevention", "First Aid", "Security", "Food Safety", "Workplace Safety", "Inspections and Support", "Accident Reporting", "Control of Hazardous Substances", "Supervision of Health Club", "Emergency Procedures and Incident Control", "Emergency Power", "Engineering Safety Inspections", "Water Hygiene", "Human Resources and Team Members" ]
    
    var sop = [
        [
            ("External locks"),
            ("Secondary locking device for entry and connecting doors"),
            ("Entry door viewer"),
            ("Self-closing entry door"),
            ("In room safes or central safety deposit boxes provided")
        ],
        [
            ("The hotel complies with the requirements of local fire safety enforcement laws."),
            ("Fire drills involving all team members are conducted at least semi-annually."),
            ("The fire alarm system includes automatic detection and audible alarms."),
            ("All team members are trained in fire evacuation procedures at least once a year."),
            ("Mandatory checklist relating to fire alarm system, fire detection, emergency lighting and portable firefighting equipment completed and recorded.")
        ],
        [
            ("The hotel has qualified first aiders."),
            ("We provide this facility for both team members, guests and members of the public."),
            ("First aid requisites are checked regularly.")
        ],
        [
            ("Security cameras are provided in certain areas as a deterrent to crime.")
        ],
        [
            ("Our hotel follows the principles of HACCP (Hazard Analysis and Critical Control Points)"),
            ("Guidelines in line with local and national food hygiene regulations and receives inspection from local authority officials.")
        ],
        [
            ("This hotel arranges for periodic internal inspections to ensure hazards are identified and removed or control measures implemented."),
            ("We have also an External Prevention Service, from FREMAP Company, which is responsible for ensuring good compliance of prevention and workplace safety measures establishing the national Law 31/1995 on Prevention of Workplace Risks.")
        ],
        [
            ("Periodic inspections undertake to support safety and general welfare conditions."),
            ("The aim is to confirm compliance with local and national legislation within the country of operation."),
            ("The inspections confirm compliance or highlight hazards requiring attention."),
            ("Reports are presented to management.")
        ],
        [
            ("Our FREMAP's prevention technician performs the investigation of all those accidents occurring in the Hotel and cause injury or property damage.")
        ],
        [
            ("The supply and use of substances in hotels is controlled as is the provision of personal protective equipment."),
            ("All products containing chemicals are accompanied by a safety sheet established by the national law, where product features are exposed, and safety data.")
        ],
        [
            ("This issue is recognized and clear signage outlines the Hotel's specific safety procedures.")
        ],
        [
            ("The hotel has procedures covering a wide variety of crisis situations."),
            ("These procedures cover such items as chemical spillage, guest illness, food contamination, bomb threats etc.")
        ],
        [
            ("The hotel has emergency backup designated lighting and power to key systems and equipment.")
        ],
        [
            ("There are periodic inspections/ maintenance on specific items of equipment.")
        ],
        [
            ("Water hygiene assessments and regular sampling carried out."),
            ("A system of water temperature monitoring and showerhead cleaning is in place."),
            ("The hotel maintenance staff receives training in treatment and water hygiene regularly.")
        ],
        [
            ("Periodic electrical inspections are carried out.")
        ],
        [
            ("Gas Equipment (e.g. boilers) are periodically maintained/ serviced.")
        ],
        [
            ("A procedure exists for visiting contractors."),
            ("Must sign and receive a copy of an ID card that must be returned when leaving the premises."),
            ("Permits to work are used for high risk work tasks, identified as Hot Works, Roof Works etc.")
        ],
        [
            ("Safety and security training within the hotel is carried out as part of the induction program that is given to all staff when he joins the team (including trainees)."),
            ("Team members are encouraged to raise suggestions for improvements or safety concerns with their elected representative or line manager."),
            ("Team members recognize the importance of working in a safe manner as identified through the induction and departmental training received.")
        ]
    ]
}

