//
//  User+CoreDataProperties.swift
//  T02_Green
//
//  Created by Garie on 11/25/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//
//

import Foundation
import CoreData


extension User {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<User> {
        return NSFetchRequest<User>(entityName: "User")
    }

    @NSManaged public var password: String?
    @NSManaged public var role: String?
    @NSManaged public var username: String?
    @NSManaged public var points: Int32
    @NSManaged public var room: NSSet?

}

// MARK: Generated accessors for room
extension User {

    @objc(addRoomObject:)
    @NSManaged public func addToRoom(_ value: Room)

    @objc(removeRoomObject:)
    @NSManaged public func removeFromRoom(_ value: Room)

    @objc(addRoom:)
    @NSManaged public func addToRoom(_ values: NSSet)

    @objc(removeRoom:)
    @NSManaged public func removeFromRoom(_ values: NSSet)

}
