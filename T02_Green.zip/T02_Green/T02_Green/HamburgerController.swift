//
//  HamburgerController.swift
//  T02_Green
//
//  Created by Garie on 11/9/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//

import UIKit

class HamburgerController: UIViewController {
    
    var curUser : String?
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func roomStatus(_ sender: Any) {
    }
    
    @IBAction func sopInfo(_ sender: Any) {
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func cancelAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func tapRecognizer(_ sender: UITapGestureRecognizer) {
        if sender.location(in: sender.view).x > 300.0 {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    //function to send data to next view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "roomStatus" {
            //passing username to next controller
            if let destination = segue.destination as? UINavigationController{
                let destinationVC = destination.topViewController as! myRSTableViewController
                destinationVC.curUser = curUser
            }
        }
        else if segue.identifier == "toRewards" {
            //passing username to next controller
            if let destination = segue.destination as? UINavigationController{
                let destinationVC = destination.topViewController as! rewardTableController
                destinationVC.curUser = curUser!
            }
        }
        else if segue.identifier == "toSOP" {
            //passing username to next controller
            if let destination = segue.destination as? UINavigationController{
                let destinationVC = destination.topViewController as! mySopTableViewController
                destinationVC.curUser = curUser!
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


}
