//
//  rewardTableController.swift
//  T02_Green
//
//  Created by Garie on 11/26/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//

import UIKit

class rewardTableController: UITableViewController {
    
    var userDatabase : [User] = []
    var curUser: String = "test2"
    var currentUser : User?
    var userPoints : Int32 = 0

   
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Rewards"
        //getting database values
        reloadData()
        getUser()
        //display user points
        pointDisplay.title = "Current Points: \(userPoints)"

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getUser(){
        for users in userDatabase {
            if users.username == curUser{
                currentUser = users
                userPoints = (currentUser?.points)!
                return
            }
        }
    }
    
    func reloadData() {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            print("Cannot fetch app delegate")
            return
        }
        //getting the actual storage object
        let managedContext = appDelegate.persistentContainer.viewContext
        
        do {
            //loading in to local variable
            userDatabase = try managedContext.fetch(User.fetchRequest())
        }
        catch let error as NSError {
            print("Cannot load data: \(error)")
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return rewards.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "rewardCell", for: indexPath)
        
        cell.backgroundColor = UIColor(red: 50, green: 200, blue: 200, alpha: 50)
        
        cell.textLabel?.textColor = UIColor.black
        cell.detailTextLabel?.textColor = UIColor.black

        cell.textLabel?.text = rewards[indexPath.row].reward
        cell.detailTextLabel?.text = String(rewards[indexPath.row].cost) + " Points"
        cell.imageView?.image = resizeImage(image: rewards[indexPath.row].image, scaledToSize: CGSize(width: 50,height: 50))
        

        return cell
    }
    
    func resizeImage(image:UIImage, scaledToSize newSize:CGSize) -> UIImage{
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0);
        image.draw(in: CGRect(origin: CGPoint.zero, size: CGSize(width: newSize.width, height: newSize.height)))
        let newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    
    //if user selects row, check if they have enough points and respond accordingly
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if userPoints >= rewards[indexPath.row].cost {
            userPoints -= Int32(rewards[indexPath.row].cost)
            pointDisplay.title = "Current Points: \(userPoints)"
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                print("Cannot fetch app delegate")
                return
            }
            let managedContext = appDelegate.persistentContainer.viewContext
            userDatabase[userDatabase.index(of: currentUser!)!].points = userPoints
            
            do {
                try managedContext.save()
                self.tableView.reloadData()
            }
            catch let error as NSError {
                print("There was an error with saving: \(error)")
            }
            let alert = UIAlertController(title: "Reward purchased", message: "Congrats! You earned a(n) \(self.rewards[indexPath.row].reward)", preferredStyle: UIAlertControllerStyle.alert)
            let okayAction = UIAlertAction(title: "Okay", style: .default) {
                UIAlertAction in
                alert.dismiss(animated: true, completion: nil)
            }
            alert.addAction(okayAction)
            self.present(alert, animated: true, completion: nil)
        } else {
            let alert = UIAlertController(title: "Insufficient Points", message: "Sorry, you don't have enough points for this reward yet.", preferredStyle: UIAlertControllerStyle.alert)
            let okayAction = UIAlertAction(title: "Okay", style: .default) {
                UIAlertAction in
                alert.dismiss(animated: true, completion: nil)
            }
            alert.addAction(okayAction)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    //function to send data to next view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toHamburger" {
            //passing username to next controller
            if let destination = segue.destination as? HamburgerController{
                destination.curUser = curUser
            }
        }
        
    }

    
    //items to populate the rewards menu with
    var rewards : [(reward : String, cost : Int, image : UIImage)] = [
        ("Extra half hour lunch break", 50, #imageLiteral(resourceName: "1200-dietitian-lunch-wide-sandwich")),
        ("Free drink",100, #imageLiteral(resourceName: "drink")),
        ("Free meal", 250, #imageLiteral(resourceName: "meal")),
        ("Three-day weekend", 350, #imageLiteral(resourceName: "calendar")),
        ("Gift card", 400, #imageLiteral(resourceName: "gift_card")),
        ("Day off", 450, #imageLiteral(resourceName: "dayOff")),
        ("Fossil watch", 600, #imageLiteral(resourceName: "download-1")),
        ("Electric scooter", 700, #imageLiteral(resourceName: "download")),
        ("Discounted Hotel Room", 900, #imageLiteral(resourceName: "percent")),
        ("Flat screen TV", 1500, #imageLiteral(resourceName: "television")),
        ("Vacation", 2000, #imageLiteral(resourceName: "beach")),
        ("20% Christmas bonus", 3000, #imageLiteral(resourceName: "dollar")),
        ("Brand new car", 5000, #imageLiteral(resourceName: "car")),
        
    ]

    @IBOutlet weak var pointDisplay: UIBarButtonItem!
}
