//
//  Room+CoreDataProperties.swift
//  T02_Green
//
//  Created by Garie on 11/25/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//
//

import Foundation
import CoreData


extension Room {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Room> {
        return NSFetchRequest<Room>(entityName: "Room")
    }

    @NSManaged public var number: Int16
    @NSManaged public var type: String?
    @NSManaged public var status: String?
    @NSManaged public var user: User?

}
