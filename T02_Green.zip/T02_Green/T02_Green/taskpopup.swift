//
//  taskpopup.swift
//  T02_Green
//
//  Created by OKEGBE BRYAN C on 11/9/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//

import UIKit

class taskpopup: UIViewController {

    //unused controller. may be implemented later
    @IBOutlet weak var popupView: UIView!
    @IBAction func back(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    override func viewDidLoad() {
        super.viewDidLoad()
//        popupView.layer.masksToBounds = true
        popupView.layer.cornerRadius = 10
        popupView.layer.masksToBounds = true

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
