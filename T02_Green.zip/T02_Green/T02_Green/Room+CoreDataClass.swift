//
//  Room+CoreDataClass.swift
//  T02_Green
//
//  Created by Garie on 11/25/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Room)
public class Room: NSManagedObject {

}
