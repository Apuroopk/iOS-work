//
//  Task Controller.swift
//  T02_Green
//
//  Created by OKEGBE BRYAN C on 11/9/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//

import UIKit

class Task_Controller: UITableViewController {
    var taskArray = ["BED MAKING", "VACCUMING", "TOILET CLEANING", "DUSTING", "WINDOW WIPING", "ARRANGING ITEMS IN ROOM"]
     var boolArray : [Bool] = [false,false,false,false,false,false]
   
    // Deeper list of what to do for the bathroom
    var bathroomDuties = [
        ("Clean counter, sink, toilet and shower"),
        ("Restock towels, washcloths, shampoo and soap"),
        ("Sweep and mop floors"),
        ("Wipe down mirrors")
    ]
    
    // Deeper list for what to do in the bedroom
    var bedroomDuties = [
        ("Strip and make bed"),
        ("Maitre the corners of the sheet"),
        ("Check under bed for personal belongings"),
        ("Vacuum floor"),
        ("Take out all the trash")
    ]
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.separatorStyle = UITableViewCellSeparatorStyle.none

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return taskArray.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "taskCell", for: indexPath)

        // Configure the cell...
        cell.textLabel?.text = taskArray[indexPath.row]
        cell.textLabel?.adjustsFontSizeToFitWidth = true
        cell.textLabel?.textColor = UIColor.white
//        cell.textLabel?.font

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //Change the color of the button here
        self.tableView.cellForRow(at: indexPath)?.textLabel?.textColor = UIColor(red:0.21, green:0.79, blue:0.73, alpha:1.0)
        boolArray[indexPath.row] = true
        checkBool()
    }
    
    func checkBool () {
        for element in boolArray {
            if !element{
                return
            }
        }
        self.dismiss(animated: true, completion: nil)
        //self.performSegue(withIdentifier: "todoReturn", sender: self)
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
