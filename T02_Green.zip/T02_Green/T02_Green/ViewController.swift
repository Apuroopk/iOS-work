//
//  ViewController.swift
//  T02_Green
//
//  Created by Amanda Lowe on 10/24/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    //global variables for storing username and password
    var userDatabase : [User] = []
    var usernames : [String] = []
    //tracking the user currently using the app
    var curUser : String?

    @IBOutlet weak var loginLabel: UILabel!
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }
    //hiding neccessary items at startup
    override func viewDidLoad() {
        super.viewDidLoad()
        loginButton.isEnabled = false
        loginButton.isHidden = true
        loginLabel.isHidden = true
        passwordField.isSecureTextEntry = true
        passwordField.addTarget(self, action: #selector(self.textChanged(field:)), for: UIControlEvents.editingChanged)
        usernameField.addTarget(self, action: #selector(self.textChanged(field:)), for: UIControlEvents.editingChanged)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //retrieving data from database
    func reloadData() {
        usernames = []
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            print("Cannot fetch app delegate")
            return
        }
        //getting the actual storage object
        let managedContext = appDelegate.persistentContainer.viewContext
        
        do {
            //loading in to local variable
            userDatabase = try managedContext.fetch(User.fetchRequest())
            for users in userDatabase {
                usernames.append(users.username!)
            }
        }
        catch let error as NSError {
            print("Cannot load data: \(error)")
        }
    }
    
    //activates when login button is clicked
    @IBAction func loginAction(_ sender: UIButton) {
        reloadData()
        if(usernames.contains(usernameField.text!)){
            if(userDatabase[usernames.index(of: usernameField.text!)!].password == passwordField.text!){
                print("access approved")
                curUser = usernameField.text
            } else {
                accessDenied()
            }
        } else {
            accessDenied()
        }
    }
    
    //alert controller fro when login is incorrect
    func accessDenied(){
        passwordField.text = ""
        let alert = UIAlertController(title: "Invalid Login", message: "The username or password is incorrect", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    //unlocs login button when text fields are filled out
    @objc func textChanged(field: UITextField){
        if((usernameField.text?.characters.count)! > 0 && (passwordField.text?.characters.count)! > 0){
            loginButton.isHidden = false
            loginButton.isEnabled = true
            loginLabel.isHidden = false
            UIView.transition(with: loginButton, duration: 0.4, options: .transitionCrossDissolve, animations: nil, completion: nil)
            UIView.transition(with: loginLabel, duration: 0.4, options: .transitionCrossDissolve, animations: nil, completion: nil)
        }
    }
    
    //function to send data to next view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //passing username to next controller
        if let destination = segue.destination as? UINavigationController{
            //actual destination view controller since it is embedded
            let detinationVC = destination.topViewController as! myRSTableViewController
            detinationVC.curUser = curUser
        }
    }
    
    
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
}
