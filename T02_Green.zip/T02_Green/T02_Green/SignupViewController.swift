//
//  SignupViewController.swift
//  T02_Green
//
//  Created by Garie on 10/31/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//

import UIKit
import CoreData

class SignupViewController: UIViewController {
    
    @IBOutlet weak var accountLabel: UILabel!
    var userDatabase : [User] = []
    var usernames : [String] = []

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        //hiding button and adding selector to fields
        signupButton.isHidden = true
        signupButton.isEnabled = false
        accountLabel.isHidden = true
        passwordOneField.isSecureTextEntry = true
        passwordOneField.addTarget(self, action: #selector(self.textChanged(field:)), for: UIControlEvents.editingChanged)
        passwordTwoField.isSecureTextEntry = true
        passwordTwoField.addTarget(self, action: #selector(self.textChanged(field:)), for: UIControlEvents.editingChanged)
        usernameField.addTarget(self, action: #selector(self.textChanged(field:)), for: UIControlEvents.editingChanged)
        
        reloadData()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func signupButtonAction(_ sender: UIButton) {
        if(passwordOneField.text! == passwordTwoField.text!) && !usernames.contains(usernameField.text!){
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                print("Cannot fetch app delegate")
                return
            }
            //retrieving core data to save user
            let managedContext = appDelegate.persistentContainer.viewContext
            let user = User(entity: User.entity(), insertInto: managedContext)
            user.username = usernameField.text!
            user.password = passwordOneField.text!
            user.role = "Employee"
            user.points = 100
            do {
                //saving the changes on core data
                try managedContext.save()
                self.dismiss(animated: true, completion: nil)
            }
            catch let error as NSError {
                print("There was an error with saving: \(error)")
            }
        } else {
            //checking if values are satisfactory
            if usernames.contains(usernameField.text!) {
                let alert = UIAlertController(title: "Username", message: "The username is already taken", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(okAction)
                self.present(alert, animated: true, completion: nil)
            } else {
                let alert = UIAlertController(title: "Password", message: "The passwords provided do not match", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(okAction)
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    func reloadData() {
        usernames = []
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            print("Cannot fetch app delegate")
            return
        }
        //getting the actual storage object
        let managedContext = appDelegate.persistentContainer.viewContext
        
        do {
            //loading in to local variable
            userDatabase = try managedContext.fetch(User.fetchRequest())
            for users in userDatabase {
                usernames.append(users.username!)
            }
        }
        catch let error as NSError {
            print("Cannot load data: \(error)")
        }
    }
    //unlocks signup button when text is filled out
    @objc func textChanged(field: UITextField){
        if((usernameField.text?.characters.count)! > 0 && (passwordOneField.text?.characters.count)! > 0 && (passwordTwoField.text?.characters.count)! > 0){
            signupButton.isHidden = false
            signupButton.isEnabled = true
            accountLabel.isHidden = false
            UIView.transition(with: signupButton, duration: 0.4, options: .transitionCrossDissolve, animations: nil, completion: nil)
            UIView.transition(with: accountLabel, duration: 0.4, options: .transitionCrossDissolve, animations: nil, completion: nil)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordOneField: UITextField!
    @IBOutlet weak var passwordTwoField: UITextField!
    @IBOutlet weak var signupButton: UIButton!
    
}
