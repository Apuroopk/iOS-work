//
//  GameController.swift
//  T01_Green
//
//  Created by Garie on 9/16/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//

import UIKit
import GameplayKit
import AVFoundation

class GameController: UIViewController {
    //swift file that links to second view controller. This is where game mechanics should be stored.
    
    //global variables for tracking game progress
    var seconds = 0
    var matches = 0
    var misses = 0
    var firstCard = -1
    var timer = Timer()
    var timerActive = false
    var buttonArray : Array<UIButton> = []
    var matchArray : Array<UIButton> = []
    var hideArray : Array<UIButton> = []
    var pictureArrayValues : Array<Int> = []
    var count = 0
    var backgroundPlayer : AVAudioPlayer?
    var soundEffectPlayer: AVAudioPlayer?
    @IBOutlet var pauseBack: UIImageView!
    @IBOutlet var resumeButton: UIButton!
    @IBOutlet var startOverButton: UIButton!
    var buttonLabel = ""
    @IBOutlet var quitGameButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //adding buttons to array for easier manipulation
         buttonAppending()
        //attaching handler to buttons
        for button in buttonArray {
            button.addTarget(self, action: #selector(GameController.buttonClicked), for: .touchUpInside)
            
        }
        //starting game
        startNewGame()
        runTimer()
        pauseBack.isHidden = true
        resumeButton.isHidden = true
        startOverButton.isHidden = true
        print(pictureArrayValues)
        quitGameButton.isHidden = true

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //method that starts timer
    func runTimer() {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(self.updateTimer)), userInfo:nil, repeats: true)
    }
    
    // Pause game
    @IBAction func pauseGame(_ sender: UIButton) {
        pauseBack.isHidden = false
        resumeButton.isHidden = false
        startOverButton.isHidden = false
        quitGameButton.isHidden = false
        timer.invalidate()
        button1.isHidden = true
        button2.isHidden = true
        button3.isHidden = true
        button4.isHidden = true
        button5.isHidden = true
        button6.isHidden = true
        button7.isHidden = true
        button8.isHidden = true
        button9.isHidden = true
        button10.isHidden = true
        button11.isHidden = true
        button12.isHidden = true
        button13.isHidden = true
        button14.isHidden = true
        button15.isHidden = true
        button16.isHidden = true

        
    }
    // Resume game
    @IBAction func resumeGame(_ sender: UIButton) {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(self.updateTimer)), userInfo:nil, repeats: true)
        hiding()
        hidingAllButtonsThatMatched()
    }
    
    // Start game over
    @IBAction func startOver(_ sender: UIButton) {
        startNewGame()
        runTimer()
        hiding()
        shuffle()
       
        print (pictureArrayValues)
    }
    
    //method that updates timer seconds
    @objc func updateTimer() {
        if !timerActive {
            return
        }
        seconds -= 1
        if seconds == 10 {
            playSoundEffects(file: "Japanese Temple Bell Small-SoundBible.com-113624364")
        }
        //end game if time is up
        if(seconds < 1) {
            timerActive = false
            playBackground(file: "Evil_Laugh_1-Timothy-64737261")
            let alert = UIAlertController(title: "Game Over", message: "You ran out of time!", preferredStyle: UIAlertControllerStyle.alert)
            let restartAction = UIAlertAction(title: "Restart Game", style: UIAlertActionStyle.default) {
                UIAlertAction in
                self.startNewGame()
            }
           alert.addAction(restartAction)
            self.present(alert, animated: true, completion: nil)
        }
        timerLabel.text = "\(seconds)s"
    }
    
    func shuffle() {
        //using imported function to shuffle array
        pictureArrayValues = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: pictureArrayValues) as! Array<Int>
    }
    
    //handler for buttons that reveals image associated to them when touched
    @objc func buttonClicked(_ sender: UIButton?) {
        //preventing cards from being flipped over twice
        
        //This loop will allow the cards to be flipped over only when the button has the back of card image.
        if(sender?.image(for: .normal) != #imageLiteral(resourceName: "backOfCard")) {
            return
        }
        
        if count <= 2 {
            
            if (count == 2) {
                flipdown()
            }
            
            if (count < 2) {
             count = count + 1
        if sender == button1 {
             matchArray.append(button1)
            button1.setImage(revealImage(image: pictureArrayValues[0]), for: .normal)
            UIView.transition(with: button1, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
     
        } else if sender == button2 {
            
            matchArray.append(button2)
            button2.setImage(revealImage(image: pictureArrayValues[1]), for: .normal)
             UIView.transition(with: button2, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
           
        } else if sender == button3 {
           
            matchArray.append(button3)
            button3.setImage(revealImage(image: pictureArrayValues[2]), for: .normal)
             UIView.transition(with: button3, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
            
        } else if sender == button4 {
           
             matchArray.append(button4)
            button4.setImage(revealImage(image: pictureArrayValues[3]), for: .normal)
             UIView.transition(with: button4, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
           
        } else if sender == button5 {
            
            matchArray.append(button5)
            button5.setImage(revealImage(image: pictureArrayValues[4]), for: .normal)
             UIView.transition(with: button5, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
           
        } else if sender == button6 {
           
            matchArray.append(button6)
            button6.setImage(revealImage(image: pictureArrayValues[5]), for: .normal)
             UIView.transition(with: button6, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
            
        } else if sender == button7 {
            
             matchArray.append(button7)
            button7.setImage(revealImage(image: pictureArrayValues[6]), for: .normal)
            UIView.transition(with: button7, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
          
           
        } else if sender == button8 {
            
            matchArray.append(button8)
            button8.setImage(revealImage(image: pictureArrayValues[7]), for: .normal)
             UIView.transition(with: button8, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
            
        } else if sender == button9 {
            
             matchArray.append(button9)
            button9.setImage(revealImage(image: pictureArrayValues[8]), for: .normal)
             UIView.transition(with: button9, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
           
        } else if sender == button10 {
            
            matchArray.append(button10)
            button10.setImage(revealImage(image: pictureArrayValues[9]), for: .normal)
             UIView.transition(with: button10, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
           
        } else if sender == button11 {
           
            matchArray.append(button11)
            button11.setImage(revealImage(image: pictureArrayValues[10]), for: .normal)
             UIView.transition(with: button11, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
           
        } else if sender == button12 {
            
            matchArray.append(button12)
            button12.setImage(revealImage(image: pictureArrayValues[11]), for: .normal)
             UIView.transition(with: button12, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
            
        } else if sender == button13 {
            
            matchArray.append(button13)
            button13.setImage(revealImage(image: pictureArrayValues[12]), for: .normal)
             UIView.transition(with: button13, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
           
        } else if sender == button14 {
           
            matchArray.append(button14)
            button14.setImage(revealImage(image: pictureArrayValues[13]), for: .normal)
             UIView.transition(with: button14, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
            
        } else if sender == button15 {
         
            matchArray.append(button15)
            button15.setImage(revealImage(image: pictureArrayValues[14]), for: .normal)
             UIView.transition(with: button15, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
            
        } else if sender == button16 {
            
             matchArray.append(button16)
             button16.setImage(revealImage(image: pictureArrayValues[15]), for: .normal)
             UIView.transition(with: button16, duration: 0.4, options: .transitionFlipFromRight, animations: nil, completion: nil)
                }
            
         }
        }
    }
   
    //returns image associated to button when called from button handler and checks if two cards are matching
    
    //Game logic for the cards
    
    func revealImage(image: Int) -> UIImage {
        //check if there is a match or miss
        
        if firstCard == -1 {
            firstCard = image
            playSoundEffects(file: "Woosh-Mark_DiAngelo-4778593")
        } else if(firstCard == image) {
          
            matches += 1
             firstCard = -1
            matchesLabel.text = "Matches: " + String(matches)
            playSoundEffects(file: "Glass Breaking-SoundBible.com-1765179538")
            matchArray[0].isHidden = true
            matchArray[1].isHidden = true
            
            hideArray.append(matchArray[0])
            hideArray.append(matchArray[1])
            
            matchArray.removeAll()
           
            if matches == 8 {
                timer.invalidate()
                hideArray.removeAll()
                playBackground(file: "SMALL_CROWD_APPLAUSE-Yannick_Lemieux-1268806408")
                let alert = UIAlertController(title: "You Won", message: "You matched all of the tiles!", preferredStyle: UIAlertControllerStyle.alert)
                let restartAction = UIAlertAction(title: "Restart Game", style: UIAlertActionStyle.default) {
                    UIAlertAction in
                    self.startNewGame()
                    self.runTimer()
                }
                alert.addAction(restartAction)
                self.present(alert, animated: true, completion: nil)
            }
        } else {
           
            matchArray.removeAll()
            misses += 1
            missesLabel.text = "Misses: " + String(misses)
            firstCard = -1
            playSoundEffects(file: "Woosh-Mark_DiAngelo-4778593")
          
        }
      
        //returning image of appropriate card
        if image ==  0 {
            return #imageLiteral(resourceName: "bats")
        } else if image == 1 {
            return #imageLiteral(resourceName: "blackCat")
        } else if image == 2 {
            return #imageLiteral(resourceName: "frankenstein")
        } else if image == 3 {
            return #imageLiteral(resourceName: "goblin")
        } else if image == 4 {
            return #imageLiteral(resourceName: "poison")
        } else if image == 5 {
            return #imageLiteral(resourceName: "skullAndBones")
        } else if image == 6 {
            return #imageLiteral(resourceName: "spiders")
        } else if image == 7 {
            return #imageLiteral(resourceName: "witch")
        }
        return #imageLiteral(resourceName: "backOfCard")
    }
    
    //resets all values to default when new game is started or time is up
    func startNewGame() {
        pictureArrayValues.removeAll()
        hideArray.removeAll()
        for index in stride(from: 0, through: 7, by: 1){
            pictureArrayValues.append(index)
            pictureArrayValues.append(index)
        }
        hiding()
        shuffle()
        print(pictureArrayValues)
        for button in buttonArray {
            button.setImage(#imageLiteral(resourceName: "backOfCard"), for: .normal)
        }
        seconds = 60
        matches = 0
        misses = 0
        matchesLabel.text = "Matches: " + String(matches)
        missesLabel.text = "Misses: " + String(matches)
        firstCard = -1
        timerActive = true
        playBackground(file: "bensound-creepy")
    }
    
    func flipdown() {
        count = 0
        for button in buttonArray {
            button.setImage(#imageLiteral(resourceName: "backOfCard"), for: .normal)
        }
    }
    
    func hidingAllButtonsThatMatched(){
        for button in hideArray {
            button.isHidden = true
        }
    }
    
    func hiding () {
        pauseBack.isHidden = true
        resumeButton.isHidden = true
        startOverButton.isHidden = true
        quitGameButton.isHidden = true
        button1.isHidden = false
        button2.isHidden = false
        button3.isHidden = false
        button4.isHidden = false
        button5.isHidden = false
        button6.isHidden = false
        button7.isHidden = false
        button8.isHidden = false
        button9.isHidden = false
        button10.isHidden = false
        button11.isHidden = false
        button12.isHidden = false
        button13.isHidden = false
        button14.isHidden = false
        button15.isHidden = false
        button16.isHidden = false
    }
    
    func buttonAppending () {
        buttonArray.append(button1)
        buttonArray.append(button2)
        buttonArray.append(button3)
        buttonArray.append(button4)
        buttonArray.append(button5)
        buttonArray.append(button6)
        buttonArray.append(button7)
        buttonArray.append(button8)
        buttonArray.append(button9)
        buttonArray.append(button10)
        buttonArray.append(button11)
        buttonArray.append(button12)
        buttonArray.append(button13)
        buttonArray.append(button14)
        buttonArray.append(button15)
        buttonArray.append(button16)
    }
    
    func playBackground(file: String) {
        guard let sound = NSDataAsset(name: file) else {
            print("File not found!")
            return
        }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            backgroundPlayer = try AVAudioPlayer(data:sound.data, fileTypeHint: AVFileType.mp3.rawValue)
            guard let player = backgroundPlayer else {return}
            
            player.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }
    func playSoundEffects(file: String) {
        guard let sound = NSDataAsset(name: file) else {
            print("File not found!")
            return
        }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            soundEffectPlayer = try AVAudioPlayer(data:sound.data, fileTypeHint: AVFileType.mp3.rawValue)
            guard let player = soundEffectPlayer else {return}
            
            player.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var matchesLabel: UILabel!
    @IBOutlet weak var missesLabel: UILabel!
    
    
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    @IBOutlet weak var button5: UIButton!
    @IBOutlet weak var button6: UIButton!
    @IBOutlet weak var button7: UIButton!
    @IBOutlet weak var button8: UIButton!
    @IBOutlet weak var button9: UIButton!
    @IBOutlet weak var button10: UIButton!
    @IBOutlet weak var button11: UIButton!
    @IBOutlet weak var button12: UIButton!
    @IBOutlet weak var button13: UIButton!
    @IBOutlet weak var button14: UIButton!
    @IBOutlet weak var button15: UIButton!
    @IBOutlet weak var button16: UIButton!
 
}

