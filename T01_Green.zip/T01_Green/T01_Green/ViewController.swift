//
//  ViewController.swift
//  T01_Green
//
//  Created by Amanda Lowe on 9/14/17.
//  Copyright © 2017 Amanda Lowe. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //swift file associated with first view controller. modify if needing to control actions on "start" screen.
    
    @IBOutlet weak var playButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        playButton.alpha = 0.0
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIView.animate(withDuration: 0.8, delay: 0.4, options: UIViewAnimationOptions.curveEaseOut, animations: {
           
            self.playButton.alpha = 1
            self.view.layoutIfNeeded()
        }, completion: nil)
    }


}

