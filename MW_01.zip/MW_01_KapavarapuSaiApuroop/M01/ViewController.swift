//
//  ViewController.swift
//  M01
//
//  Created by Sai Apuroop Kapavarapu on 10/17/17.
//  Copyright © 2017 Sai Apuroop Kapavarapu. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
  var LicensePlate:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
         self.GetLicenseImages(self.LicensePlate, inView: DisplayLicenseImages)
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBOutlet weak var DisplayLicenseImages: UIImageView!
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func GetLicenseImages(_ uri : String, inView: UIImageView){
        
        let url = URL(string: uri)
        
        let task = URLSession.shared.dataTask(with: url!) {responseData,response,error in
            if error == nil{
                if let data = responseData {
                    
                    DispatchQueue.main.async {
                        inView.image = UIImage(data: data)
                    }
                    
                }else {
                    
                }
            }else{
                
            }
        }
        task.resume()
        
    }
}

