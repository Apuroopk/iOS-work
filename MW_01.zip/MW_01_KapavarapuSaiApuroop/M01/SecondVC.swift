//
//  SecondVC.swift
//  M01
//
//  Created by Ankita Kota on 10/19/17.
//  Copyright © 2017 Sai Apuroop Kapavarapu. All rights reserved.
//

import UIKit

class SecondVC: UIViewController {
 var LicensePlate:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
 self.GetLicenseImages(self.LicensePlate, inView: DisplayLicenseImages)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet weak var DisplayLicenseImages: UIImageView!
    func GetLicenseImages(_ uri : String, inView: UIImageView){
        
        let url = URL(string: uri)
        
        let task = URLSession.shared.dataTask(with: url!) {responseData,response,error in
            if error == nil{
                if let data = responseData {
                    
                    DispatchQueue.main.async {
                        inView.image = UIImage(data: data)
                    }
                    
                }else {
                    
                }
            }else{
                
            }
        }
        task.resume()
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
