//
//  MyTableViewController.swift
//  M01
//
//  Created by Sai Apuroop Kapavarapu on 10/17/17.
//  Copyright © 2017 Sai Apuroop Kapavarapu. All rights reserved.
//

import UIKit


var currentScore = 0

class MyTableViewController: UITableViewController {
    var sendImage: IndexPath!
    var dataSource : [[(stateName: String,stateNickname: String,stateURL: String,cellColor: UIColor,Status:Bool)]] = [
        
        [(stateName: "Alabama",stateNickname: "Yellowhammer State",stateURL: "http://www.15q.net/us1/al14.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Alaska",stateNickname: "The Last Frontier",stateURL: "http://www.15q.net/us1/ak12.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Arizona",stateNickname: "The Grand Canyon State",stateURL: "http://www.15q.net/us1/az09b.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Arkansas",stateNickname: "Arkansas",stateURL: "http://www.15q.net/us1/ar07.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "California",stateNickname: "The Golden State",stateURL: "http://www.15q.net/us1/ca12.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Colorado",stateNickname: "The Centennial State",stateURL: "http://www.15q.net/us1/co01.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Connecticut",stateNickname: "The Constitution state",stateURL: "http://www.15q.net/us1/ct16.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Delaware",stateNickname: "The First State",stateURL: "http://www.15q.net/us1/de08.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Florida",stateNickname: "The Sunshine State",stateURL: "http://www.15q.net/us1/fl10.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Georgia",stateNickname: "The Peach State",stateURL: "http://www.15q.net/us1/ga16c.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Hawaii",stateNickname: "The Aloha State",stateURL: "http://www.15q.net/us2/hi94.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Idaho",stateNickname: "The Gem State",stateURL: "http://www.15q.net/us2/id09.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Illinois",stateNickname: "Prairie State",stateURL: "http://www.15q.net/us2/il18.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Indiana",stateNickname: "The Hoosier State",stateURL: "http://www.15q.net/us2/in14.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Iowa",stateNickname: "The Hawkeye State",stateURL: "http://www.15q.net/us2/ia12.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Kansas",stateNickname: "The Sunflower State",stateURL: "http://www.15q.net/us2/ks08.jpg",cellColor: UIColor.white,Status:false),
        (stateName: "Kentucky",stateNickname: "The Bluegrass State",stateURL: "http://www.15q.net/us2/ky08.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Lousiana",stateNickname: "The Pelican State",stateURL: "http://www.15q.net/us2/la18a.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Maine",stateNickname: "The Paine Tree State",stateURL: "http://www.15q.net/us2/me00a.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Maryland",stateNickname: "The Old Line State",stateURL: "http://www.15q.net/us2/md16.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Massachusetts",stateNickname: "The Bay State",stateURL: "http://www.15q.net/us3/ma03a.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Michigan",stateNickname: "The Great Lakes state",stateURL: "http://www.15q.net/us3/mi14.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Minnesota",stateNickname: "The North Star State",stateURL: "http://www.15q.net/us3/mn10b.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Mississippi",stateNickname: "The Magnolia State",stateURL: "http://www.15q.net/us3/ms13.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Missouri",stateNickname: "The Show Me State",stateURL: "http://www.15q.net/us3/mo10.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Montana",stateNickname: "The Treasure State",stateURL: "http://www.15q.net/us3/mt17a.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Nebraska",stateNickname: "The Cornhusker State",stateURL: "http://www.15q.net/us3/ne18.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "Nevada",stateNickname: "The Silver State",stateURL: "http://www.15q.net/us3/nv17.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "New Hampshire",stateNickname: "The Granite State",stateURL: "http://www.15q.net/us3/nh01.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "New Jersey",stateNickname: "The Garden State",stateURL: "http://www.15q.net/us3/nj15.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "New Mexico",stateNickname: "The Land of Enchantment",stateURL: "http://www.15q.net/us4/nm00a.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "New York",stateNickname: "The Empire State",stateURL: "http://www.15q.net/us4/ny10.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "North Carolina",stateNickname: "The Tar Heel State",stateURL: "http://www.15q.net/us4/nc10.jpg",cellColor: UIColor.white,Status:false),
         (stateName: "North Dakota",stateNickname: "The Peace Garden State",stateURL: "http://www.15q.net/us4/nd17.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Ohio",stateNickname: "The Buckeye State",stateURL: "http://www.15q.net/us4/oh13.jpg",cellColor: UIColor.white,Status:false),
        (stateName: "Oklahoma",stateNickname: "The Sooner State",stateURL: "http://www.15q.net/us4/ok18.jpg",cellColor: UIColor.white,Status:false),
        (stateName: "Oregon",stateNickname: "The Beaver State",stateURL: "http://www.15q.net/us4/or08.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Pennsylvania",stateNickname: "The Keystone State",stateURL: "http://www.15q.net/us4/pa06.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Rhode Island",stateNickname: "The Ocean State",stateURL: "http://www.15q.net/us4/ri97.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "South Carolina",stateNickname: "The Palmetto State",stateURL: "http://www.15q.net/us4/sc17.jpg",cellColor: UIColor.white,Status:false),
        (stateName: "South Dakota",stateNickname: "Mount Rushmore State",stateURL: "http://www.15q.net/us5/sd16.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Tennessee",stateNickname: "The Volunteer State",stateURL: "http://www.15q.net/us5/tn12.jpg",cellColor: UIColor.white,Status:false),
        (stateName: "Texas",stateNickname: "The Lone Star State",stateURL: "http://www.15q.net/us5/tx13.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Utah",stateNickname: "The Beehive State",stateURL: "http://www.15q.net/us5/ut08.jpg",cellColor: UIColor.white,Status:false)],
        
        [(stateName: "Vermont",stateNickname: "The Green Mountain State",stateURL: "http://www.15q.net/us5/vt91.jpg",cellColor: UIColor.white,Status:false),
        (stateName: "Virginia",stateNickname: "The Old Dominion State",stateURL: "http://www.15q.net/us5/va15.jpg",cellColor: UIColor.white,Status:false)],
        
        
        [(stateName: "Washington",stateNickname: "The Evergreen State",stateURL: "http://www.15q.net/us5/wa11.jpg",cellColor: UIColor.white,Status:false),
        (stateName: "West Virginia",stateNickname: "The Mountain State",stateURL: "http://www.15q.net/us5/wv07.jpg",cellColor: UIColor.white,Status:false),
        (stateName: "Wisconsin",stateNickname: "The Badger State",stateURL: "http://www.15q.net/us5/wi01.jpg",cellColor: UIColor.white,Status:false),
        (stateName: "Wyoming",stateNickname: "The Equality or Cowboy State",stateURL: "http://www.15q.net/us5/wy18.jpg",cellColor: UIColor.white,Status:false)]
    ]
    
    var sectionHeaders = ["A","C","D","F","G","H","I","K","L","M","N","O","P","R","S","T","U","V","W"]
   
    
    @IBOutlet weak var scoreButton: UIBarButtonItem!
    
    @IBAction func resetGame(_ sender: Any) {
        
        let alertControllerResetGame = UIAlertController(title: "Please Verify !",message: "Do you want to reset the game", preferredStyle: .alert)
        let noResetGame = UIAlertAction(title: "No",style: .default) { (result : UIAlertAction) in print("No") }
        let yesResetGame = UIAlertAction(title: "Yes",style: .destructive) { (result : UIAlertAction) in self.scoreButton.title = "0/50"  }
        alertControllerResetGame.addAction(noResetGame)
        alertControllerResetGame.addAction(yesResetGame)
        self.present(alertControllerResetGame,animated: true,completion: nil)
        
       
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return dataSource.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return dataSource[section].count
    }

   
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let cellData: (stateName: String,stateNickname: String,stateURL: String,cellColor: UIColor,Status:Bool) = dataSource[indexPath[0]][indexPath[1]]
        cell.accessoryType = .detailDisclosureButton
        cell.textLabel?.text = cellData.stateName
        cell.detailTextLabel?.text = cellData.stateNickname
        let Colors = UIColor(red: 175/255, green: 234/255, blue: 143/255, alpha: 1.0)
        if !dataSource[indexPath[0]][indexPath[1]].4
        {
            cell.backgroundColor = UIColor.white
            
        }
        else
        {
            cell.backgroundColor = Colors
            
        }
        return cell
    }
    
    override func becomeFirstResponder() -> Bool {
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue,sender: Any?)
    {
        print(sendImage)
        //Get index path and destination view controller.
        if let indexPath = sendImage{
            if let destination = segue.destination as? SecondVC {
                destination.LicensePlate = dataSource[indexPath[0]][indexPath[1]].2
            }
        }
    }
 
    @IBOutlet weak var ScoreValue: UIBarButtonItem!
    override func tableView(_ tableView: UITableView,    titleForHeaderInSection section: Int)     -> String?
    {
        return sectionHeaders[section]
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if dataSource[indexPath[0]][indexPath[1]].4
        {
            let EachCell = tableView.cellForRow(at: indexPath) as! UITableViewCell
            
            
            // Create the alert controller.
            let alertController = UIAlertController(title: "Please check",     message: "Do you want to reset \(EachCell.textLabel!.text!)",     preferredStyle: .alert)
            
            // Create action for "Cancel", with a handler closure.
            let cancelAction = UIAlertAction(title: "No",style: .default) {
                (result : UIAlertAction) in
                self.tableView.reloadData()
                
            }
            
            // Create action for "Start Again”,with a handler closure.
            let startAgainAction = UIAlertAction(title: "Yes",style: .default)
            {
                (result : UIAlertAction) in
                self.dataSource[indexPath[0]][indexPath[1]].4 = !self.dataSource[indexPath[0]][indexPath[1]].4
                self.tableView.reloadData()
                currentScore = currentScore - 1
                self.ScoreValue.title = "\(currentScore) /50"
                //self.PlayBackGroundMusic(fileNamed: "song")
            }
            
            
            // Add the actions to the controller.
            alertController.addAction(startAgainAction)
            alertController.addAction(cancelAction)
            // Present the alert controller to the user.
            self.present(alertController, animated: true, completion: nil)
            
        }
        else
        {
           // PlayBackGroundMusic(fileNamed: "song")
            dataSource[indexPath[0]][indexPath[1]].4 = !dataSource[indexPath[0]][indexPath[1]].4
            self.tableView.reloadData()
            currentScore = currentScore + 1
            self.ScoreValue.title = "\(currentScore) /50"
        }
    }
    
    
    
    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        //Pass the indexPath as sender
        sendImage = indexPath
        
        print(sendImage)
        self.performSegue(withIdentifier: "LicenseBoard", sender: indexPath)
        
    }
    
    
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        
        return sectionHeaders[section].count
    }
     
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    

}
