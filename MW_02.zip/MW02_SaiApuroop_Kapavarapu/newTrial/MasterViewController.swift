//
//  MasterViewController.swift
//  newTrial
//
//  Created by Sai Apuroop Kapavarapu on 12/3/17.
//  Copyright © 2017 Sai Apuroop Kapavarapu. All rights reserved.
//

import UIKit

//The below structs are declared to convert the incoming json data and later store as an array
struct Table1: Decodable {
    let rollingStockID: String
    let railroadID: String
    let roadNum: String
    let type: String
    let imagePath: String
}

struct Table2: Decodable {
    let railroadID: String
    let roadFullName: String
    let roadAbbr: String
}

//Variables needed for storing the data entered in the texfields
var rollingStockIDTF: UITextField!
var railroadIDTF: UITextField!
var roadNumTF: UITextField!
var typeTF: UITextField!
var roadFullNameTF: UITextField!
var roadAbbrTF: UITextField!

//Variables needed for segue
var roadNameId1 : String!
var rrAb1 : String!
var typeId1 : String!


var imageUrl : URL?
var imagePathId1 : String = ""

class MasterViewController: UITableViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate{

    //Array to store all the values coming values from JSON
    var valuesArray1 = [Table1]()
    var valuesArray2 = [Table2]()
    
    var pickImage = UIImagePickerController()
    
    var detailViewController: DetailViewController? = nil
    //var managedObjectContext: NSManagedObjectContext? = nil
    var objects = [Any]()


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        pickImage.delegate = self
        
        //To load the first selected detail for the view
        if tableView.numberOfSections == 0 {
            let indexPath = IndexPath(row: 0, section: 0)
            tableView.selectRow(at: indexPath, animated: true, scrollPosition: .bottom)
            performSegue(withIdentifier: "showDetail", sender: self)
        }
        
        navigationItem.leftBarButtonItem = editButtonItem

        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(insertNewObject(_:)))
        navigationItem.rightBarButtonItem = addButton
        if let split = splitViewController {
            let controllers = split.viewControllers
            detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
            
            retrievingValues1()
            retrievingValues2()

        }
    }

    override func viewWillAppear(_ animated: Bool) {
        clearsSelectionOnViewWillAppear = splitViewController!.isCollapsed
        super.viewWillAppear(animated)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

     //Adding the alert controller for the + button in the Master View Controller
    @objc
    func insertNewObject(_ sender: Any) {
        pickImage.sourceType = .savedPhotosAlbum
        pickImage.allowsEditing = false
        present(self.pickImage,animated: true,completion: nil)
    }
    
    //Code for Image picker allowing user to select from the images of the gallery
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        //info[UIImagePickerControllerOriginalImage] as? UIImage
        
        
        imageUrl = (info[UIImagePickerControllerReferenceURL] as! URL)
        //print("The image Url is \(imageUrl?.absoluteString)")
//        imagePathId1 = String(describing: imageUrl)
        
//        let nameForImage = imageUrl?.lastPathComponent
//        let directoryForImage = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first as! String
//        let pathForImage = directoryForImage + "/" + nameForImage!
//        imagePathId1 = pathForImage
        
        print("The image url is \(imagePathId1)")
        
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage
        let data = UIImagePNGRepresentation(image)
        do {
            try data?.write(to: URL(fileURLWithPath: imagePathId1))
        }
        catch {
            print("error displaying image")
        }
        
        dismiss(animated: true, completion: nil)
        displayAlertController()
    }
    
    func displayAlertController () {
        let alertController = UIAlertController(title: "Add item ? ",message: "Do you want to add an Entry ? ",preferredStyle: .alert)
        // First create action for Start Again using a handler closure.
        let addAction = UIAlertAction(title: "Save", style: .default)
        {
            (result : UIAlertAction) in
            rollingStockIDTF = alertController.textFields![0] as UITextField
            railroadIDTF = alertController.textFields![1] as UITextField
            roadNumTF = alertController.textFields![2] as UITextField
            typeTF = alertController.textFields![3] as UITextField
            roadFullNameTF = alertController.textFields![4] as UITextField
            roadAbbrTF = alertController.textFields![5] as UITextField
            self.insertingValues1()
            self.insertingValues2()
            self.tableView.reloadData()
        }
        // Creating action for cancel action
        let cancelAction = UIAlertAction(title: "Cancel",       style: .destructive)
        { (result : UIAlertAction) in print("Cancel") }
        // Adding the Text fields into the place holder
        alertController.addTextField { (textField : UITextField!) -> Void in textField.placeholder = "Enter rollingStockID" }
        alertController.addTextField { (textField : UITextField!) -> Void in textField.placeholder = "Enter railroadID" }
        alertController.addTextField { (textField : UITextField!) -> Void in textField.placeholder = "Enter roadNumber" }
        alertController.addTextField { (textField : UITextField!) -> Void in textField.placeholder = "Enter type" }
        alertController.addTextField { (textField : UITextField!) -> Void in textField.placeholder = "Enter road Full Name" }
        alertController.addTextField { (textField : UITextField!) -> Void in textField.placeholder = "Enter road Abbreviation" }
        // Present the alert controller to the user.
        self.present(alertController, animated: true, completion: nil)
        // Add the actions to the controller.
        alertController.addAction(cancelAction)
        alertController.addAction(addAction)
    }

    // Here I have used two different functions for retrieving values from 2 tables. One function for each url.
    func retrievingValues1 () {
        let url = URL(string:"https://cs.okstate.edu/~skapava/Mad.php/select/MW02_RollingStock")!
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        let task = session.dataTask(with: url) { (data,response,error) in
            guard error == nil else { print("Error in session call: \(String(describing: error))")
                return }
            guard let result = data else { print("No data Received")
                return }
            do {
                self.valuesArray1 = try JSONDecoder().decode([Table1].self, from: result)
                print("The value stored in Array 1 are \(self.valuesArray1)")
            } catch {
                print("Error serializing JSON Data: \(error)")
            }
        }
        task.resume()
    }
    
    // This function retrieves the values from table 2 . It performs select query on the database and returns results
    func retrievingValues2 () {
        let url = URL(string:"https://cs.okstate.edu/~skapava/Mad.php/select/MW02_Railroad")!
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        let task = session.dataTask(with: url) { (data,response,error) in
            guard error == nil else { print("Error in session call: \(String(describing: error))")
                return }
            guard let result = data else { print("No data Received")
                return }
            do {
                self.valuesArray2 = try JSONDecoder().decode([Table2].self, from: result)
                print("The value stored in Array 2 are \(self.valuesArray2)")
            } catch {
                print("Error serializing JSON Data: \(error)")
            }
        }
        task.resume()
    }
    
    // This is for inserting values into the database through the URL when user clicks the + button and enters the data
    func insertingValues1 () {
        //Modyfying image url
        let newImagePath = "\(imageUrl!)"
        var modifiedUrl = newImagePath.replacingOccurrences(of: "/", with: ")")
        modifiedUrl = modifiedUrl.replacingOccurrences(of: "-", with: "_")
        modifiedUrl = modifiedUrl.replacingOccurrences(of: "&", with: "(")
        modifiedUrl = modifiedUrl.replacingOccurrences(of: "=", with: "[")
        modifiedUrl = modifiedUrl.replacingOccurrences(of: "?", with: "]")
        modifiedUrl = modifiedUrl.replacingOccurrences(of: ":", with: "$")
        modifiedUrl = modifiedUrl.replacingOccurrences(of: ".", with: "*")
        
        
        // Url for inserting values into DB
        let url = URL(string:"https://cs.okstate.edu/~skapava/Mad.php/insert/MW02_RollingStock/"
            + "\(rollingStockIDTF.text!)/"
            + "\(railroadIDTF.text!)/"
            + "\(roadNumTF.text!)/"
            + "\(typeTF.text!)/"
            + "\(modifiedUrl)")
        
        //Add the inserted values into array 1
        let table1 = Table1(rollingStockID: "\(rollingStockIDTF.text!)", railroadID: "\(railroadIDTF.text!)", roadNum: "\(roadNumTF.text!)", type: "\(typeTF.text!)", imagePath: "\(modifiedUrl)")
        self.valuesArray1.append(table1)
        print("The value stored in Array 1 are \(self.valuesArray1)")
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        let task = session.dataTask(with: url!) { (data,response,error) in
            guard error == nil else { print("Error in session call: \(String(describing: error))")
                return }
            do {
                let myJSON =  try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                //parsing the json
                if let parseJSON = myJSON {
                    //creating a string
                    var msg : String!
                    //getting the json response
                    msg = parseJSON["message"] as! String?
                    //printing the response
                    print(msg)
                }
                
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
    // This function inserts values into table 2 taking the data the user has entered in the alert view controller
    func insertingValues2 () {
        let url = URL(string:"https://cs.okstate.edu/~skapava/Mad.php/insert/MW02_Railroad/"
            + "\(railroadIDTF.text!)/"
            + "\(roadFullNameTF.text!)/"
            + "\(roadAbbrTF.text!)/")
        
        //Add inserted values into array2
        let table2 = Table2(railroadID: "\(railroadIDTF.text!)",roadFullName: "\(roadFullNameTF.text!)",roadAbbr: "\(roadAbbrTF.text!)")
        self.valuesArray2.append(table2)
        print("The value stored in Array 2 are \(self.valuesArray2)")
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        let task = session.dataTask(with: url!) { (data,response,error) in
            guard error == nil else { print("Error in session call: \(String(describing: error))")
                return }
            do {
                let myJSON =  try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                //parsing the json
                if let parseJSON = myJSON {
                    //creating a string
                    var msg : String!
                    //getting the json response
                    msg = parseJSON["message"] as! String?
                    //printing the response
                    print(msg)
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
   // The next 3 function are used to display the data on the cell for a tableView Controller
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return valuesArray1.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)

        cell.textLabel?.text = self.valuesArray2[indexPath.row].roadAbbr + " " + self.valuesArray1[indexPath.row].rollingStockID
        cell.detailTextLabel?.text = self.valuesArray1[indexPath.row].type
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        roadNameId1 = self.valuesArray2[indexPath.row].roadFullName
        rrAb1 = self.valuesArray2[indexPath.row].roadAbbr + " " + self.valuesArray1[indexPath.row].rollingStockID
        typeId1 = self.valuesArray1[indexPath.row].type
        imagePathId1 = self.valuesArray1[indexPath.row].imagePath
        performSegue(withIdentifier: "showDetail", sender: self)
    }

    // Passing the details needed over segue through the variables.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = ((segue.destination as! UINavigationController).topViewController as? DetailViewController) {
                indexPath.roadNameId2 = roadNameId1
                indexPath.rrAb2 = rrAb1
                indexPath.typeId2 = typeId1
                indexPath.imagePathId2 = imagePathId1
            }
        }
    }

    


}

