//
//  DetailViewController.swift
//  newTrial
//
//  Created by Sai Apuroop Kapavarapu on 12/3/17.
//  Copyright © 2017 Sai Apuroop Kapavarapu. All rights reserved.
//

import UIKit
import AssetsLibrary

class DetailViewController: UIViewController {

    @IBOutlet weak var detailDescriptionLabel: UILabel!
    var asset = ALAssetsLibrary()

    //Outlets neeeded for Displaying the value of images
    @IBOutlet weak var roadNameLabel: UILabel!
    @IBOutlet weak var roadAbbrLabel: UILabel!
    @IBOutlet weak var roadTypeLabel: UILabel!
    @IBOutlet weak var imageVar: UIImageView!
    
    //Variables needed for storing the information on the segue
    var roadNameId2 : String!
    var rrAb2 : String!
    var typeId2 : String!
    var imagePathId2 : String = ""
    
    func configureView() {
        // Update the user interface for the detail item.
        if let detail = detailItem {
            if let label = detailDescriptionLabel {
                label.text = detail.description
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        configureView()
        roadNameLabel.text = roadNameId2
        roadAbbrLabel.text = rrAb2
        roadTypeLabel.text = typeId2
        //imageVar.image = UIImage(contentsOfFile: imagePathId2)
        
        // Code for loading the image
        
    }
    
    // Function for accessing the image URL for retrieval
    func getUIImagefromAsseturl (url: NSURL) {
        asset.asset(for: url as URL!, resultBlock: { asset in
            if let ast = asset {
                let assetRep = ast.defaultRepresentation()
                let iref = (assetRep?.fullResolutionImage().takeUnretainedValue())!
                let image:UIImage = UIImage.init(cgImage: iref)
                self.imageVar.image = image
            }
        }, failureBlock: { error in
            print("Error: \(error)")
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var detailItem: NSDate? {
        didSet {
            // Update the view.
            configureView()
        }
    }
    
    //Modyfying the image URL so that it can be accepeted while storing and retrieving
    override func viewDidAppear(_ animated: Bool) {
        var modifiedUrl = self.imagePathId2.replacingOccurrences(of: ")", with: "/")
        modifiedUrl = modifiedUrl.replacingOccurrences(of: "_", with: "-")
        modifiedUrl = modifiedUrl.replacingOccurrences(of: "(", with: "&")
        modifiedUrl = modifiedUrl.replacingOccurrences(of: "[", with: "=")
        modifiedUrl = modifiedUrl.replacingOccurrences(of: "]", with: "?")
        modifiedUrl = modifiedUrl.replacingOccurrences(of: "$", with: ":")
        modifiedUrl = modifiedUrl.replacingOccurrences(of: "*", with: ".")
        let nsURL = NSURL(string: modifiedUrl as! String)!
        getUIImagefromAsseturl(url: nsURL)
    }

}

